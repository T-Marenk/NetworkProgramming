#include <bits/types/struct_timeval.h>
#include <stdlib.h>
#include <strings.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#define SERV_TCP_PORT 51069

void my_err(char *sptr)
{
  perror(sptr);
  exit(1);
}

// Receive data from a client with this function
void receiver(int fd_in, int fd_out) {
  // Assign needed variables
  struct timeval start, end;
  char *line = malloc(124); // Allocate space for reading lines
  ssize_t nread;

  // Read from input while there is still something to be read and calculate the amount of bytes read
  while ((nread = read(fd_in, line, 124)) > 0) write(fd_out, line, nread);

  free(line); // Free the allocated space
  close(fd_in); // Close the socket (child)
}

int main(int argc, char *argv[], char *envp[]) {
  int listenfd, newsockfd, clilen, childpid;
  struct sockaddr_in cli_addr, serv_addr;

  if ( (listenfd = socket(PF_INET, SOCK_STREAM, 0)) < 0) // Create the socket
    my_err("Failed to create socket");

  // Initialize the server address
  bzero((void *) &serv_addr, sizeof(serv_addr));
  serv_addr.sin_family = AF_INET;
  serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
  serv_addr.sin_port = htons(SERV_TCP_PORT);

  // Bind the server address to the socket
  if (bind(listenfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0)
    my_err("Failed to bind address") ;

  // Start the tcp server
  listen(listenfd, 1);
  for (;;) {
    clilen = sizeof(cli_addr); // Client process connected

    newsockfd = accept(listenfd, (struct sockaddr *) &cli_addr, &clilen); // Open a socket for the client

    if (newsockfd < 0) my_err("Failed to create connection");

    if ( (childpid = fork()) < 0)
      my_err("Failed to fork");
    else if (childpid == 0) { // Create child process to handle the data receiving
      receiver(newsockfd, newsockfd);
      exit(0);
    }
    close(newsockfd); // Close the client socket for the parent
  }
  return 0;
}
